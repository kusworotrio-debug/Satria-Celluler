KASIR SATRIA CELLULAR - ANDROID STUDIO PROJECT

Project ini adalah source project Android (WebView) yang membungkus aplikasi HTML agar berjalan seperti aplikasi Android dan menyimpan data browser secara lokal.

CARA MEMBUAT APK:
1. Buka folder project ini di Android Studio (File > Open).
2. Tunggu Gradle Sync selesai. Jika diminta, pasang Android SDK Platform 35 dan Build Tools yang direkomendasikan.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug akan muncul di app/build/outputs/apk/debug/app-debug.apk.
5. Pindahkan APK ke Samsung, buka file APK, lalu izinkan instalasi dari sumber tersebut bila diminta.

Catatan: Ini belum berupa file APK siap instal. Perlu Android Studio/Android SDK untuk proses kompilasi dan penandatanganan APK.
