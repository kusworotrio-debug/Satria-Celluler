CARA MEMBUAT APK DARI HP ANDROID (TANPA LAPTOP)

1. Ekstrak ZIP ini di HP.
2. Buka https://github.com/ lalu daftar/login.
3. Buat repository baru (misalnya satria-cellular), pilih Private atau Public.
4. Upload seluruh isi folder SatriaCellularAndroid ke repository (termasuk folder tersembunyi .github).
   PENTING: file .github/workflows/build-apk.yml harus ikut ter-upload.
5. Buka repository > tab Actions.
6. Pilih workflow "Build Satria Cellular APK" > Run workflow > Run workflow.
7. Tunggu sampai proses selesai (tanda hijau).
8. Buka hasil run, bagian Artifacts, download "Satria-Cellular-APK".
9. Ekstrak file ZIP hasil download, lalu buka app-debug.apk.
10. Jika diminta, izinkan Chrome/File Saya memasang aplikasi tidak dikenal, lalu instal.

Catatan:
- Ini menghasilkan debug APK untuk instalasi pribadi, bukan APK Play Store.
- Jangan bagikan repository jika berisi data atau konfigurasi pribadi.
- Build membutuhkan internet dan akun GitHub.
